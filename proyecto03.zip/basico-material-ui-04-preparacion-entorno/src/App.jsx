import React from "react";

const App = () => {
  return(
    <div>Soy un platzinauta</div>
  )
};

export default App;